# Delar för 3D-utskrift: svart-vanliga

150 delar, 33 sorter. Varje fil är en sluten solid i millimeter, lagd för utskrift. Antal och färger gäller den här delmängden.

| Fil | Del | Antal | Färger | Storlek (mm) |
|---|---|---:|---|---|
| `3005-brick-1-x-1.stl` | Brick  1 x  1 | 4 | 4× svart | 8.1 × 8.1 × 11.2 |
| `3004-brick-1-x-2.stl` | Brick  1 x  2 | 6 | 6× svart | 16.1 × 8.1 × 11.2 |
| `3622-brick-1-x-3.stl` | Brick  1 x  3 | 2 | 2× svart | 24.1 × 8.1 × 11.2 |
| `3009-brick-1-x-6.stl` | Brick  1 x  6 | 1 | 1× svart | 48.1 × 8.1 × 11.2 |
| `3008-brick-1-x-8.stl` | Brick  1 x  8 | 2 | 2× svart | 64.1 × 8.1 × 11.2 |
| `6111-brick-1-x-10.stl` | Brick  1 x 10 | 4 | 4× svart | 80.1 × 8.1 × 11.2 |
| `3002-brick-2-x-3.stl` | Brick  2 x  3 | 2 | 2× svart | 24.1 × 16.1 × 11.2 |
| `2456-brick-2-x-6.stl` | Brick  2 x  6 | 3 | 3× svart | 48.1 × 16.1 × 11.2 |
| `3007-brick-2-x-8.stl` | Brick  2 x  8 | 6 | 6× svart | 64.1 × 16.1 × 11.2 |
| `3024-plate-1-x-1.stl` | Plate  1 x  1 | 8 | 8× svart | 8.1 × 8.1 × 4.8 |
| `3023-plate-1-x-2.stl` | Plate  1 x  2 | 5 | 5× svart | 16.1 × 8.1 × 4.8 |
| `15573-plate-1-x-2-with-groove-with-1-centre-stud-witho.stl` | Plate  1 x  2 with Groove with 1 Centre Stud, without Understud | 32 | 32× svart | 16.1 × 8.1 × 4.8 |
| `3623-plate-1-x-3.stl` | Plate  1 x  3 | 4 | 4× svart | 24.1 × 8.1 × 4.8 |
| `3710-plate-1-x-4.stl` | Plate  1 x  4 | 2 | 2× svart | 32.1 × 8.1 × 4.8 |
| `3460-plate-1-x-8.stl` | Plate  1 x  8 | 1 | 1× svart | 64.1 × 8.1 × 4.8 |
| `4477-plate-1-x-10.stl` | Plate  1 x 10 | 4 | 4× svart | 80.1 × 8.1 × 4.8 |
| `3021-plate-2-x-3.stl` | Plate  2 x  3 | 2 | 2× svart | 24.1 × 16.1 × 4.8 |
| `3020-plate-2-x-4.stl` | Plate  2 x  4 | 2 | 2× svart | 32.1 × 16.1 × 4.8 |
| `3034-plate-2-x-8.stl` | Plate  2 x  8 | 4 | 4× svart | 64.1 × 16.1 × 4.8 |
| `3832-plate-2-x-10.stl` | Plate  2 x 10 | 4 | 4× svart | 80.1 × 16.1 × 4.8 |
| `3031-plate-4-x-4.stl` | Plate  4 x  4 | 1 | 1× svart | 32.1 × 32.1 × 4.8 |
| `3035-plate-4-x-8.stl` | Plate  4 x  8 | 2 | 2× svart | 64.1 × 32.1 × 4.8 |
| `3030-plate-4-x-10.stl` | Plate  4 x 10 | 1 | 1× svart | 80.1 × 32.1 × 4.8 |
| `3029-plate-4-x-12.stl` | Plate  4 x 12 | 1 | 1× svart | 96.1 × 32.1 × 4.8 |
| `3033-plate-6-x-10.stl` | Plate  6 x 10 | 3 | 3× svart | 80.1 × 48.1 × 4.8 |
| `3028-plate-6-x-12.stl` | Plate  6 x 12 | 1 | 1× svart | 96.1 × 48.1 × 4.8 |
| `3298-slope-brick-33-3-x-2.stl` | Slope Brick 33  3 x  2 | 2 | 2× svart | 16.1 × 24.1 × 11.2 |
| `11477-slope-brick-curved-2-x-1.stl` | Slope Brick Curved  2 x  1 | 28 | 28× svart | 8.1 × 16.0 × 6.4 |
| `3070b-tile-1-x-1-with-groove.stl` | Tile  1 x  1 with Groove | 1 | 1× svart | 8.1 × 8.1 × 3.2 |
| `63864-tile-1-x-3.stl` | Tile  1 x  3 | 1 | 1× svart | 24.1 × 8.1 × 3.2 |
| `2431-tile-1-x-4-with-groove.stl` | Tile  1 x  4 with Groove | 2 | 2× svart | 32.1 × 8.1 × 3.2 |
| `4162-tile-1-x-8.stl` | Tile  1 x  8 | 1 | 1× svart | 64.1 × 8.1 × 3.2 |
| `15535-tile-2-x-2-round-with-hole.stl` | Tile  2 x  2 Round with Hole | 8 | 8× svart | 16.0 × 16.0 × 3.2 |
