# Delar för 3D-utskrift: gron-vanliga

159 delar, 36 sorter. Varje fil är en sluten solid i millimeter, lagd för utskrift. Antal och färger gäller den här delmängden. Knoppar 4.80 mm, rör 6.51 mm, stolpar 3.20 mm (grepp +0.00 mm).

| Fil | Del | Antal | Färger | Storlek (mm) |
|---|---|---:|---|---|
| `3005-brick-1-x-1.stl` | Brick  1 x  1 | 8 | 8× grön | 7.9 × 7.9 × 11.2 |
| `3010-brick-1-x-4.stl` | Brick  1 x  4 | 2 | 2× grön | 31.9 × 7.9 × 11.2 |
| `3009-brick-1-x-6.stl` | Brick  1 x  6 | 2 | 2× grön | 47.9 × 7.9 × 11.2 |
| `3008-brick-1-x-8.stl` | Brick  1 x  8 | 2 | 2× grön | 63.9 × 7.9 × 11.2 |
| `6111-brick-1-x-10.stl` | Brick  1 x 10 | 6 | 6× grön | 79.9 × 7.9 × 11.2 |
| `3941-brick-2-x-2-round-without-reinforcement.stl` | Brick  2 x  2 Round without Reinforcement | 4 | 4× grön | 15.9 × 15.9 × 11.2 |
| `3024-plate-1-x-1.stl` | Plate  1 x  1 | 11 | 11× grön | 7.9 × 7.9 × 4.8 |
| `3023-plate-1-x-2.stl` | Plate  1 x  2 | 2 | 2× grön | 15.9 × 7.9 × 4.8 |
| `3623-plate-1-x-3.stl` | Plate  1 x  3 | 1 | 1× grön | 23.9 × 7.9 × 4.8 |
| `3710-plate-1-x-4.stl` | Plate  1 x  4 | 4 | 4× grön | 31.9 × 7.9 × 4.8 |
| `3666-plate-1-x-6.stl` | Plate  1 x  6 | 13 | 13× grön | 47.9 × 7.9 × 4.8 |
| `3460-plate-1-x-8.stl` | Plate  1 x  8 | 1 | 1× grön | 63.9 × 7.9 × 4.8 |
| `4477-plate-1-x-10.stl` | Plate  1 x 10 | 2 | 2× grön | 79.9 × 7.9 × 4.8 |
| `3034-plate-2-x-8.stl` | Plate  2 x  8 | 1 | 1× grön | 63.9 × 15.9 × 4.8 |
| `3832-plate-2-x-10.stl` | Plate  2 x 10 | 1 | 1× grön | 79.9 × 15.9 × 4.8 |
| `2445-plate-2-x-12.stl` | Plate  2 x 12 | 1 | 1× grön | 95.9 × 15.9 × 4.8 |
| `30565-plate-4-x-4-corner-round.stl` | Plate  4 x  4 Corner Round | 14 | 14× grön | 31.9 × 31.9 × 4.8 |
| `3032-plate-4-x-6.stl` | Plate  4 x  6 | 1 | 1× grön | 47.9 × 31.9 × 4.8 |
| `3030-plate-4-x-10.stl` | Plate  4 x 10 | 1 | 1× grön | 79.9 × 31.9 × 4.8 |
| `3958-plate-6-x-6.stl` | Plate  6 x  6 | 1 | 1× grön | 47.9 × 47.9 × 4.8 |
| `3033-plate-6-x-10.stl` | Plate  6 x 10 | 1 | 1× grön | 79.9 × 47.9 × 4.8 |
| `3028-plate-6-x-12.stl` | Plate  6 x 12 | 1 | 1× grön | 95.9 × 47.9 × 4.8 |
| `4286-slope-brick-33-3-x-1.stl` | Slope Brick 33  3 x  1 | 3 | 3× grön | 7.9 × 23.9 × 11.2 |
| `3298-slope-brick-33-3-x-2.stl` | Slope Brick 33  3 x  2 | 4 | 4× grön | 15.9 × 23.9 × 11.2 |
| `3040b-slope-brick-45-2-x-1.stl` | Slope Brick 45  2 x  1 | 11 | 11× grön | 7.9 × 15.9 × 11.2 |
| `11477-slope-brick-curved-2-x-1.stl` | Slope Brick Curved  2 x  1 | 10 | 10× grön | 7.9 × 15.9 × 6.4 |
| `3070b-tile-1-x-1-with-groove.stl` | Tile  1 x  1 with Groove | 4 | 4× grön | 7.9 × 7.9 × 3.2 |
| `3069b-tile-1-x-2-with-groove.stl` | Tile  1 x  2 with Groove | 4 | 4× grön | 15.9 × 7.9 × 3.2 |
| `63864-tile-1-x-3.stl` | Tile  1 x  3 | 3 | 3× grön | 23.9 × 7.9 × 3.2 |
| `2431-tile-1-x-4-with-groove.stl` | Tile  1 x  4 with Groove | 6 | 6× grön | 31.9 × 7.9 × 3.2 |
| `6636-tile-1-x-6.stl` | Tile  1 x  6 | 3 | 3× grön | 47.9 × 7.9 × 3.2 |
| `4162-tile-1-x-8.stl` | Tile  1 x  8 | 20 | 20× grön | 63.9 × 7.9 × 3.2 |
| `14769-tile-2-x-2-round-with-round-underside-stud.stl` | Tile  2 x  2 Round with Round Underside Stud | 1 | 1× grön | 15.9 × 15.9 × 3.2 |
| `3068b-tile-2-x-2-with-groove.stl` | Tile  2 x  2 with Groove | 1 | 1× grön | 15.9 × 15.9 × 3.2 |
| `26603-tile-2-x-3.stl` | Tile  2 x  3 | 3 | 3× grön | 23.9 × 15.9 × 3.2 |
| `87079-tile-2-x-4-with-groove.stl` | Tile  2 x  4 with Groove | 6 | 6× grön | 31.9 × 15.9 × 3.2 |
