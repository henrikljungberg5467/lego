# Delar för 3D-utskrift: ljusgra

36 delar, 3 sorter. Varje fil är en sluten solid i millimeter, lagd för utskrift. Antal och färger gäller den här delmängden.

| Fil | Del | Antal | Färger | Storlek (mm) |
|---|---|---:|---|---|
| `32073-technic-axle-5.stl` | Technic Axle  5 | 7 | 7× ljus blågrå | 40.1 × 4.8 × 4.8 |
| `32123b-technic-bush-1-2-smooth-with-axle-hole-semi-redu.stl` | Technic Bush 1/2 Smooth with Axle Hole Semi-Reduced | 22 | 22× ljus blågrå | 7.1 × 7.1 × 4.1 |
| `3713-technic-bush-with-two-flanges.stl` | Technic Bush with Two Flanges | 7 | 7× ljus blågrå | 7.2 × 7.2 × 8.1 |
