# Delar för 3D-utskrift: morkgra

11 delar, 5 sorter. Varje fil är en sluten solid i millimeter, lagd för utskrift. Antal och färger gäller den här delmängden.

| Fil | Del | Antal | Färger | Storlek (mm) |
|---|---|---:|---|---|
| `3008-brick-1-x-8.stl` | Brick  1 x  8 | 3 | 3× mörk blågrå | 64.1 × 8.1 × 11.2 |
| `87083-technic-axle-4-with-stop.stl` | Technic Axle  4 with Stop | 1 | 1× mörk blågrå | 32.1 × 6.3 × 6.3 |
| `10928-technic-gear-8-tooth-reinforced.stl` | Technic Gear  8 Tooth Reinforced | 2 | 2× mörk blågrå | 10.0 × 10.0 × 8.1 |
| `3648b-technic-gear-24-tooth-with-single-axle-hole.stl` | Technic Gear 24 Tooth with Single Axle Hole | 4 | 4× mörk blågrå | 25.9 × 25.9 × 7.8 |
| `98138-tile-1-x-1-round-with-groove.stl` | Tile  1 x  1 Round with Groove | 1 | 1× mörk blågrå | 8.0 × 8.0 × 3.2 |
