# Delar för 3D-utskrift: gul

62 delar, 16 sorter. Varje fil är en sluten solid i millimeter, lagd för utskrift. Antal och färger gäller den här delmängden. Knoppar 4.80 mm, rör 6.51 mm, stolpar 3.20 mm (grepp +0.00 mm).

| Fil | Del | Antal | Färger | Storlek (mm) |
|---|---|---:|---|---|
| `3004-brick-1-x-2.stl` | Brick  1 x  2 | 8 | 8× gul | 15.9 × 7.9 × 11.2 |
| `11211-brick-1-x-2-with-two-studs-on-one-side.stl` | Brick  1 x  2 with Two Studs on One Side | 1 | 1× gul | 15.9 × 9.7 × 11.2 |
| `3009-brick-1-x-6.stl` | Brick  1 x  6 | 2 | 2× gul | 47.9 × 7.9 × 11.2 |
| `3008-brick-1-x-8.stl` | Brick  1 x  8 | 7 | 7× gul | 63.9 × 7.9 × 11.2 |
| `3007-brick-2-x-8.stl` | Brick  2 x  8 | 2 | 2× gul | 63.9 × 15.9 × 11.2 |
| `3024-plate-1-x-1.stl` | Plate  1 x  1 | 2 | 2× gul | 7.9 × 7.9 × 4.8 |
| `3666-plate-1-x-6.stl` | Plate  1 x  6 | 2 | 2× gul | 47.9 × 7.9 × 4.8 |
| `3020-plate-2-x-4.stl` | Plate  2 x  4 | 1 | 1× gul | 31.9 × 15.9 × 4.8 |
| `3034-plate-2-x-8.stl` | Plate  2 x  8 | 7 | 7× gul | 63.9 × 15.9 × 4.8 |
| `54200-slope-brick-31-1-x-1-x-0-667.stl` | Slope Brick 31  1 x  1 x  0.667 | 2 | 2× gul | 7.9 × 7.9 × 6.2 |
| `11477-slope-brick-curved-2-x-1.stl` | Slope Brick Curved  2 x  1 | 18 | 18× gul | 7.9 × 15.9 × 6.4 |
| `32072-technic-gear-4-knob.stl` | Technic Gear  4 Knob | 1 | 1× gul | 23.9 × 24.0 × 7.9 |
| `3070b-tile-1-x-1-with-groove.stl` | Tile  1 x  1 with Groove | 2 | 2× gul | 7.9 × 7.9 × 3.2 |
| `87079-tile-2-x-4-with-groove.stl` | Tile  2 x  4 with Groove | 3 | 3× gul | 31.9 × 15.9 × 3.2 |
| `55981-wheel-rim-14-x-18-with-holes-on-both-sides-needs.stl` | Wheel Rim 14 x 18 with Holes on Both Sides (Needs Work) | 2 | 2× gul | 16.8 × 16.8 × 15.9 |
| `56145-wheel-rim-20-x-30-with-6-spokes-and-external-rib.stl` | Wheel Rim 20 x 30 with 6 Spokes and External Ribs | 2 | 2× gul | 30.4 × 30.4 × 20.1 |
