# Delar för 3D-utskrift: gron-technic

11 delar, 4 sorter. Varje fil är en sluten solid i millimeter, lagd för utskrift. Antal och färger gäller den här delmängden.

| Fil | Del | Antal | Färger | Storlek (mm) |
|---|---|---:|---|---|
| `32140-technic-beam-2-x-4-liftarm-bent-90.stl` | Technic Beam  2 x  4 Liftarm Bent 90 | 4 | 4× grön | 15.3 × 31.2 × 8.1 |
| `32526-technic-beam-3-x-5-bent-90.stl` | Technic Beam  3 x  5 Bent 90 | 2 | 2× grön | 23.3 × 39.2 × 8.1 |
| `32278-technic-beam-15.stl` | Technic Beam 15 | 3 | 3× grön | 7.4 × 119.1 × 8.1 |
| `6536-technic-cross-block-1-x-2-axle-pin.stl` | Technic Cross Block 1 x 2 (Axle/Pin) | 2 | 2× grön | 8.1 × 8.1 × 15.2 |
