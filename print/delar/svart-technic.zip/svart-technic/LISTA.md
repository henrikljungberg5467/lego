# Delar för 3D-utskrift: svart-technic

51 delar, 16 sorter. Varje fil är en sluten solid i millimeter, lagd för utskrift. Antal och färger gäller den här delmängden.

| Fil | Del | Antal | Färger | Storlek (mm) |
|---|---|---:|---|---|
| `32014-technic-angle-connector-6-90-degree.stl` | Technic Angle Connector #6 (90 degree) | 2 | 2× svart | 8.1 × 15.6 × 15.5 |
| `32062-technic-axle-2-notched.stl` | Technic Axle  2 Notched | 5 | 5× svart | 16.1 × 4.8 × 4.8 |
| `3705-technic-axle-4.stl` | Technic Axle  4 | 6 | 6× svart | 32.1 × 4.8 × 4.8 |
| `3706-technic-axle-6.stl` | Technic Axle  6 | 3 | 3× svart | 48.1 × 4.8 × 4.8 |
| `3707-technic-axle-8.stl` | Technic Axle  8 | 2 | 2× svart | 64.1 × 4.8 × 4.8 |
| `59443-technic-axle-joiner-inline-smooth.stl` | Technic Axle Joiner Inline Smooth | 2 | 2× svart | 6.9 × 6.9 × 16.1 |
| `32140-technic-beam-2-x-4-liftarm-bent-90.stl` | Technic Beam  2 x  4 Liftarm Bent 90 | 1 | 1× svart | 15.3 × 31.2 × 8.1 |
| `60484-technic-beam-3-x-3-t-shaped.stl` | Technic Beam  3 x  3 T-shaped | 1 | 1× svart | 23.2 × 23.2 × 8.1 |
| `32064a-technic-brick-1-x-2-with-axlehole-with-open-side.stl` | Technic Brick  1 x  2 with Axlehole with Open Sides and Stud Blocker | 1 | 1× svart | 16.1 × 8.1 × 11.2 |
| `3700-technic-brick-1-x-2-with-hole.stl` | Technic Brick  1 x  2 with Hole | 2 | 2× svart | 16.1 × 8.1 × 11.2 |
| `3702-technic-brick-1-x-8-with-holes.stl` | Technic Brick  1 x  8 with Holes | 4 | 4× svart | 64.1 × 8.1 × 11.2 |
| `42135-technic-connector-axle-bush-type-2.stl` | Technic Connector (Axle/Bush) Type 2 | 2 | 2× svart | 8.1 × 7.1 × 15.6 |
| `61332-technic-pin-with-friction-type-2.stl` | Technic Pin with Friction Type 2 | 12 | 12× svart | 16.1 × 6.3 × 5.9 |
| `32001-technic-plate-2-x-6-with-holes.stl` | Technic Plate  2 x  6 with Holes | 4 | 4× svart | 48.1 × 16.1 × 4.8 |
| `3738-technic-plate-2-x-8-with-holes.stl` | Technic Plate  2 x  8 with Holes | 1 | 1× svart | 64.1 × 16.1 × 4.8 |
| `32124-technic-rotor-2-blade-with-4-studs.stl` | Technic Rotor  2 Blade with 4 Studs | 3 | 3× svart | 40.0 × 8.1 × 4.8 |
