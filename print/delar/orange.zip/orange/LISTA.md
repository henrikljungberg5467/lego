# Delar för 3D-utskrift: orange

1 delar, 1 sorter. Varje fil är en sluten solid i millimeter, lagd för utskrift. Antal och färger gäller den här delmängden.

| Fil | Del | Antal | Färger | Storlek (mm) |
|---|---|---:|---|---|
| `2432-tile-1-x-2-with-handle.stl` | Tile  1 x  2 with Handle | 1 | 1× orange | 16.1 × 8.1 × 12.8 |
